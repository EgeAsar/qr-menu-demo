export default function Page() {
  return <h1>Hello, Next.js!</h1>;
}
import { useState } from 'react';

const MENU_DATA = [
  {
    category: "Ana Yemekler",
    items: [
      { id: 1, name: "Miya Special Burger", price: 380, desc: "200g Dana eti, karamelize soğan, cheddar", hasUpsell: true },
      { id: 2, name: "Izgara Antrikot (300g)", price: 620, desc: "Taze baharatlı tereyağı ve patates püre ile", hasUpsell: false }
    ]
  },
  {
    category: "Tatlılar",
    items: [
      { id: 3, name: "San Sebastian Cheesecake", price: 190, desc: "Eritilmiş Belçika çikolatası ile", hasUpsell: false }
    ]
  }
];

export default function QrMenu() {
  const [selectedItem, setSelectedItem] = useState(null);
  const [notification, setNotification] = useState("");

  const handleItemClick = (item) => {
    if (item.hasUpsell) {
      setSelectedItem(item);
    } else {
      showNotification(`${item.name} seçildi.`);
    }
  };

  const callWaiter = (type) => {
    showNotification(`🔔 Masaya "${type}" talebi iletildi! Garsonunuz geliyor.`);
    // Burada Supabase / WebSocket üzerinden mutfak paneline anlık bildirim gider.
  };

  const showNotification = (msg) => {
    setNotification(msg);
    setTimeout(() => setNotification(""), 4000);
  };

  return (
    <div style={{ maxWidth: '480px', margin: '0 auto', fontFamily: 'sans-serif', padding: '16px', backgroundColor: '#f9fafb', minHeight: '100vh' }}>
      
      {/* Restoran Başlığı */}
      <div style={{ textAlign: 'center', marginBottom: '24px' }}>
        <h1 style={{ margin: '0', color: '#111827' }}>MİYA BİSTRO</h1>
        <p style={{ color: '#6b7280', fontSize: '14px', margin: '4px 0' }}>Masa No: 04</p>
      </div>

      {/* Bildirim Kutusu */}
      {notification && (
        <div style={{ backgroundColor: '#10b981', color: 'white', padding: '12px', borderRadius: '8px', marginBottom: '16px', textAlign: 'center', fontWeight: 'bold' }}>
          {notification}
        </div>
      )}

      {/* Menü Listesi */}
      {MENU_DATA.map((cat, idx) => (
        <div key={idx} style={{ marginBottom: '24px' }}>
          <h2 style={{ borderBottom: '2px solid #e5e7eb', paddingBottom: '8px', color: '#374151' }}>{cat.category}</h2>
          {cat.items.map((item) => (
            <div 
              key={item.id} 
              onClick={() => handleItemClick(item)}
              style={{ display: 'flex', justifyContent: 'space-between', backgroundColor: 'white', padding: '12px', borderRadius: '8px', marginBottom: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', cursor: 'pointer' }}
            >
              <div>
                <div style={{ fontWeight: 'bold', color: '#1f2937' }}>{item.name}</div>
                <div style={{ fontSize: '12px', color: '#6b7280' }}>{item.desc}</div>
              </div>
              <div style={{ fontWeight: 'bold', color: '#059669', whiteSpace: 'nowrap' }}>{item.price} TL</div>
            </div>
          ))}
        </div>
      ))}

      {/* Akıllı Çapraz Satış (Upsell) Pop-up'ı */}
      {selectedItem && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px' }}>
          <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '12px', maxWidth: '360px', width: '100%', textAlign: 'center' }}>
            <h3>Lezzeti İkiye Katlayın! 🍔</h3>
            <p style={{ color: '#4b5563' }}>{selectedItem.name} yanına Trüflü Patates ve Soğuk İçecek eklemek ister misiniz?</p>
            <button 
              onClick={() => { setSelectedItem(null); showNotification("Menü Menüsü Sepete Eklendi! (+85 TL)"); }}
              style={{ width: '100%', padding: '12px', backgroundColor: '#059669', color: 'white', border: 'none', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer', marginBottom: '8px' }}
            >
              Evet, Menü Yap (+85 TL)
            </button>
            <button 
              onClick={() => { setSelectedItem(null); showNotification("Sadece Burger Seçildi."); }}
              style={{ width: '100%', padding: '10px', backgroundColor: '#e5e7eb', color: '#374151', border: 'none', borderRadius: '6px', cursor: 'pointer' }}
            >
              Hayır, Sadece Burger
            </button>
          </div>
        </div>
      )}

      {/* Garson & Hesap Çağırma Sabit Alt Bar */}
      <div style={{ position: 'fixed', bottom: '16px', left: '50%', transform: 'translateX(-50%)', width: '90%', maxWidth: '440px', display: 'flex', gap: '8px' }}>
        <button 
          onClick={() => callWaiter("Garson Talebi")}
          style={{ flex: 1, padding: '14px', backgroundColor: '#2563eb', color: 'white', border: 'none', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' }}
        >
          🔔 Garson Çağır
        </button>
        <button 
          onClick={() => callWaiter("Hesap İstedi (Kart/Nakit)")}
          style={{ flex: 1, padding: '14px', backgroundColor: '#d97706', color: 'white', border: 'none', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' }}
        >
          💳 Hesap İste
        </button>
      </div>

    </div>
  );
}